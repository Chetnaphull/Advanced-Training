package advanced;

public class Problem5_3 {
	static void repeat(String str)
    {
        int a = str.length();
      
        StringBuffer b;
        for (int i = 0; i < a; i++)
        {
            b = new StringBuffer(); 
            int j = i;  
            int k = 0;  
      
          
            for (int k2 = j; k2 < str.length(); k2++) {
                b.insert(k, str.charAt(j));
                k++;
                j++;
            }
      
        
            j = 0;
            while (j < i)
            {
                b.insert(k, str.charAt(j));
                j++;
                k++;
            }
      
            System.out.println(b);
        }
    }
     
   
    public static void main(String[] args)
    {
        String  str = new String("CODE");
  
        repeat(str);
    }



}

