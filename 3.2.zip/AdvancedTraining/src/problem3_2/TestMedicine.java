package problem3_2;

public class TestMedicine {
public static void main(String[] args) {
		
	MedicineInfo a[] = new MedicineInfo[5];
		double i = Math.random()*4;
		int j = (int) i;
		System.out.println(j);
		
		switch(j)
		
		{
		case 1: 
			a[0] = new MedicineInfo();

		a[1] = new Tablet();
		a[0].displayLabel();
		a[1].displayLabel();
		break;
		
		case 2:
			a[2] = new MedicineInfo();
		a[3] = new Syrup();
		a[2].displayLabel();
		a[3].displayLabel();
		break;
		
		case 3:
			a[4] = new MedicineInfo();
		a[5] = new Ointment();
		a[4].displayLabel();
		a[5].displayLabel();
		break;
		
		default: System.out.println("Incorrect");
		}	

	}

}


