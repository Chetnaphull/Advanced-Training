package problem3_2;

public class MedicineInfo {

	public void displayLabel(){System.out.println("Company Name : Cool Dry");
	System.out.println("Address : Chandigarh , India");
	}
	}
    class Tablet extends MedicineInfo{
		 
		public void displayLabel(){
			System.out.println("Store in a cool dry place.");
			}
		}
    class Syrup extends  MedicineInfo{
    	
    	public void displayLabel(){
    		System.out.println("Store below 30�C.");
		}
    	}
    class Ointment extends MedicineInfo{
    	
    	public void displayLabel(){
    		System.out.println("For external use only.");
    		}
 }




