package problem3_1;

public class Instrument {

	public void inter()
	{
	}	
}
    class Piano extends Instrument{
    	public void inter() {
		System.out.println("Piano is playing tan tan tan");
	}
    }
    class Flute extends Instrument{
    	public void inter() {
			System.out.println("Flute is playing toot toot toot");
		}
	}
	class Guitar extends Instrument{
		
		public void inter() {
			System.out.println("Guitar is playing tin tin tin");
		}		
		
	}




