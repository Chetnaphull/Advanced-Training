package problem3_1;

public class Function {
public static void main(String[] args) {
		
		Instrument a[] = new Instrument[10];	
		a[0]=new Piano();
		a[1]=new Flute();
		a[2]=new Guitar();
		a[3]=new Piano();
		a[4]=new Flute();
		a[5]=new Guitar();
		a[6]=new Piano();
		a[7]=new Flute();
		a[8]=new Guitar();
		a[9]=new Piano();
	    
	    for (int i = 0; i <a.length; i++) 
	    {
	    	if(a[i] instanceof Piano) 
	    	{
	    		a[i].inter();
	    	}
	    	if(a[i] instanceof Flute)
	    	{
	    		a[i].inter();
	    	}
	    	if(a[i] instanceof Guitar) 
	    	{
	    		a[i].inter();
	    	}	
	    } 	
	}
}


