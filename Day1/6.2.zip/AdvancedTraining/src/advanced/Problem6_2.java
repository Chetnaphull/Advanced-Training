package advanced;

import java.util.Hashtable;
import java.util.Scanner;

public class Problem6_2 {
@SuppressWarnings("resource")
public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		Hashtable<String,String> pd=new Hashtable<String,String>();
		System.out.println("Enter the product id:");
		System.out.print("Enter the product name:");
		for(int i=0;i<10;i++)
		{
			pd.put(input.next(),input.next());
		}
		System.out.println("........");
		System.out.println("Product list is:");
		System.out.println(pd);
		System.out.println("Enter the product id that you want to be removed:");
		System.out.println("........");
		String pid = input.next();
		pd.remove(pid);
		
		System.out.println("item removed");
		System.out.println("the product list is:");
		System.out.println("........");
		System.out.println(pd.toString());
		System.out.println("Enter the product id  that you want to be searched:");
		System.out.println("........");
		String er=input.next();
		if(pd.containsKey(er))
		{
			System.out.println(pd.get(er));
		}
		else {
			System.out.println("not available..");
		}
	}
		

}


