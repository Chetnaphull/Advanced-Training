package problem6_4;

public class Details {

	 private String Name;
	  private long  phoneNumber;
	public String getName() {
		return Name;
	}
	public void setFirstName(String Name) {
		this.Name = Name;
	}
	
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	

	public Details(String Name,  long phoneNumber) {
		super();
		this.Name = Name;
		this.phoneNumber = phoneNumber;
	
	}
	public void setName(String nextLine) {
		// TODO Auto-generated method stub
		
	}
	  
	  

}


