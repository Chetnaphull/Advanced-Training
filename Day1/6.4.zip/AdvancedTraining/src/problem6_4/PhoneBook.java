package problem6_4;

import java.util.ArrayList;
import java.util.List;

public class PhoneBook {
	
	private List<Details> PhoneBook=new ArrayList<Details>();
    public void setPhoneBook(List<Details>obj)
    {
        PhoneBook=obj;
    }
    public void addDetails(Details DetailsObj)
    {
        PhoneBook.add(DetailsObj);
    }
    public Details viewDetailsGivenPhone(long phoneNumber)
    {
        Details obj=new Details(null,phoneNumber);

        for(Details obj1:PhoneBook)
        {
            if(obj1.getPhoneNumber()==phoneNumber)
            {
                obj=obj1;//
            }
        }
        return obj;
    }
    public boolean removeDetails(long phoneNumber)
    {
        boolean f=false;
        for(Details obj:PhoneBook)
        {
            if(obj.getPhoneNumber()==phoneNumber)
            {
                f=true;
                PhoneBook.remove(obj);
                break;
            }
        }
        return f;
    }
	

}
