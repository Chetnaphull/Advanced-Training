package advanced;

import java.util.Scanner;

public class Rectangle {

		private int length;
		private int breadth;
		private int area;
		public Rectangle ()
		{		
			length = 0;
			breadth = 0;
		}
		
		@SuppressWarnings("resource")
		void input() {
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter Length of the rectangle: ");
			length = scan.nextInt();
			System.out.println("Enter Breadth of the rectangle ");
			breadth = scan.nextInt();
		}
		void cal() {
			area=length*breadth;
		}
		void display() {
			System.out.println("Area Of a Rectangle=" +area);
		}
		public static void main(String[] args) {
			//rec1
			Rectangle rec1=new Rectangle();
			rec1.input();
			rec1.cal();
			rec1.display();
			//rec2
			Rectangle rec2=new Rectangle();
			rec2.input();
			rec2.cal();
			rec2.display();
			//rec3
			Rectangle rec3=new Rectangle();
			rec3.input();
			rec3.cal();
			rec3.display();
			//rec4
			Rectangle rec4=new Rectangle();
			rec4.input();
			rec4.cal();
			rec4.display();
			//ob5
			Rectangle rec5=new Rectangle();
			rec5.input();
			rec5.cal();
			rec5.display();
		}	
		
}
