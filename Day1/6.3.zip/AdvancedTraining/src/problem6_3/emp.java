package problem6_3;

import java.util.Vector;

public class emp {
	public static void main(String[] args) {
		Vector<Employee> d = data();
		display(d);
		}
	private static Vector<Employee> data() {

		return null;
	}
	private static void display(Vector<Employee> d)
	{
	}

	public static void main1(String[] args) {
		Employee e1=new Employee (1,"Avneet", "Punjab,India");
		Employee e2=new Employee (2,"Harsh", "Goa,India");
		Employee e3=new Employee (3,"Sam", "Delhi,India");
		Vector<Employee> d=new Vector<Employee>();
		d.add(e1);
		d.add(e2);
		d.add(e3);
		return;
	

	}

}

