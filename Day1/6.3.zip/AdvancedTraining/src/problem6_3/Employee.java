package problem6_3;

public class Employee {
	private int EmployeeNo;
	private String EmployeeName;
	private String EmployeeAddress;
	
public Employee(int No, String Name, String Address) {
		
		EmployeeNo =No;
		EmployeeName = Name;
		EmployeeAddress = Address;
	}

	public int getEmployeeNo() {
		return EmployeeNo;
	}
	public void setEmployeeNo(int No) {
		EmployeeNo = No;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	public void setEmployeeName(String Name) {
		EmployeeName = Name;
	}
	public String getEmployeeAddress() {
		return EmployeeAddress;
	}
	public void setEmployeeAddress(String Address) {
		EmployeeAddress = Address;
	}


}

