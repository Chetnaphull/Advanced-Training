package advanced;

import java.util.Scanner;

public class Problem2_1 {
	public static void main(String[] args) {
		 String[] name = {"Jenny"};
		  
  	 for ( int i = 0; i < name.length; i++ )
  	 {

  	    System.out.println(name[i].toUpperCase());
	}
  	 palindrome();
  	 
	}
	
	public static void  palindrome() {
		 String str, rev = ""; 
	      @SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
	      System.out.println("....................");
	      System.out.println("....................");
	      System.out.println("Enter a String: ");  
	      str = input.nextLine();   
	      int length = str.length();   
	      for (int i = length - 1; i >= 0; i--)
	  			rev = rev + str.charAt(i);
	      if (str.equals(rev))
	    	  

	         System.out.println("It's a palindrome string.");  
	      else  
	         System.out.println("It's not a palindrome string.");   
	   }  
	}

    
	

