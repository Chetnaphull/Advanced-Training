package advanced;

public class BankAccount4 {
	
		int accNo;
		String custName;
		String accType;
		float balance;
	   
	    public int getAccNo() {
			return accNo;
		}
		public void setAccNo(int accNo) {
			this.accNo = accNo;
		}
		public String getCustName() {
			return custName;
		}
		public void setCustName(String custName) {
			this.custName = custName;
		}
		public String getAccType() {
			return accType;
		}
		public void setAccType(String accType) {
			this.accType = accType;
		}
		public void setBalance(float balance) {
			this.balance = balance;
		}
		public float getBalance() {
	       
	        if( balance <1000)
	        {
	        try
	        {   
	            throw new NumberFormatException();
	        }
	        catch(NumberFormatException nw)
	        {
	            System.out.println("Balance is low:" +balance);
	            
	            
	        }
	        }
	        return balance;
		}
	          
	    public BankAccount4() {
	       
	        this.accNo = 100;
	        this.custName = "";
	        this.accType = "Saving";
	        this.balance = 500;
	    }
	   
	   
	    public BankAccount4(int accNo, String custName, String accType, float balance) {
			super();
			this.accNo = accNo;
			this.custName = custName;
			this.accType = accType;
			this.balance = balance;
		}
		public void deposit(float amt)
	    {
	        if(amt<0)
	        {
	            try
	            {
	                throw new NumberFormatException();
	            }
	            catch(NumberFormatException nf)
	            {
	                System.out.println("Negaive amount can't be deposit");
	            }
	        }
	        else
	        {
	            balance=(float)(getBalance()+amt);
	            System.out.println("Current balance is:" +balance);
	           
	        }    
	       	       
	    }
	     public void withdraw(float amt){
	         if(amt>1000)
	            {
	                try
	                {
	                    throw new NumberFormatException();
	                }
	                catch(NumberFormatException nf)
	                {
	                    System.out.println("INSUFFICENT BALANCE ");
	                }
	            }
	            else
	            {
	                balance=(float)(getBalance()-amt);
	                System.out.println("Current balance is:" +balance);
	               
	            } 
	    }
	     void display()
	     {
	    System.out.println("Balance is:" +getBalance());   
	     }
	   
	   
	   
	   
	    public static void main(String[] args) {
	       
	       
	        BankAccount4 ba=new BankAccount4();
	        ba.deposit(2000);
	        ba.display();
	        ba.withdraw(500);
	        ba.display();
	        ba.withdraw(2000);
	        ba.getBalance();
	        ba.display();
	       
	}

}
