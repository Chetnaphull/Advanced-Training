package advanced;

import java.util.Scanner;

public class Problem2_2 {
	public static void main(String[] args) {
		int n;
		int a,b;	
		System.out.println("Enter the total Number for sequence:- ");
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		n=scan.nextInt();
		System.out.println("Enter two numbers a & b:-");
		a=scan.nextInt();
		b=scan.nextInt();
		int i=1;
		while(i<=n) {
			System.out.print(a+" ");
			int next=a+b;
			a=b;
			b=next;
			
			i++;
		}		
		
		
	}

}


