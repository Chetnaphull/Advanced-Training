package advanced;

public class Problem5_2 {

	public static void main(String[] args) {
		
		String str= (" 23  +  45  -  (  343  /  12  ) ");
		String[] e=str.split("\\s");
		
		for(String e1:e){  
			System.out.println(e1); 
		
		}
	}


}

