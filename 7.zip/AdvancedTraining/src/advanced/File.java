package advanced;

import java.io.Closeable;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class File {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws IOException{
		
		 Scanner input=new Scanner(System.in); 
	        FileReader a = null; 
	        FileWriter b = null; 
	        try { 
	            System.out.println("Enter the source file:"); 
	            String a1=input.next(); 
	           a = new FileReader(a1); 
	            System.out.println("Enter the destination file:"); 
	            String a2=input.next();

	            File f2=new File(); 
	            if(!f2.exists()) { 
	                b= new FileWriter(a2); 
	                f2.createNewFile(); 
	                int c = a.read(); 
	                while(c!=-1) { 
	                    b.write(c); 
	                    c = a.read(); 
	                } 
	                System.out.println("File copied!!"); 
	            } else { 
	                b = new FileWriter(a2); 
	                System.out.println("whether you want to overwrite? (Yes/No)"); 
	                char ans = input.next().charAt(0);

	                if(ans=='N'||ans=='n') { 
	                    System.out.println("Error!!"); 
	                } else { 
	                    int c = a.read(); 
	                    while(c!=-1) { 
	                        b.write(c); 
	                        c = a.read(); 
	                    } 
	                    System.out.println("File updated!!"); 
	                } 
	            } 
	        } catch(IOException e) { 
	            System.out.println("File coudn't be found"); 
	        } finally { 
	            close(a); 
	            close(b); 
	        } 
	    } 
	    private boolean exists() {
		// TODO Auto-generated method stub
		return false;
	}
		private void createNewFile() {
		// TODO Auto-generated method stub
		
	}
		public static void close(Closeable stream) { 
	        try { 
	            if (stream != null) { 
	                stream.close(); 
	            } 
	        } catch(IOException e) { //... } 
	    } 
	    }
	

}


