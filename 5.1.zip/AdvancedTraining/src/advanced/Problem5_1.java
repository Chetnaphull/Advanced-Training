package advanced;

public class Problem5_1 {

	public static void main(String[] args) {
		
		 String str= "JAVA is Simple";
			
			System.out.println(str.toUpperCase()); 
			System.out.println(".........");
			System.out.println(str.toLowerCase()); 
			System.out.println(".........");
			String[] text=str.split("\\s");
			for(String t:text){  
				System.out.print(t.charAt(0)); 
				
				System.out.print(" ");
			}
			
			System.out.println(" ");
			
			String[] text1=str.split("\\s"); // Change order 
			for(String t:text1){  
				System.out.println(".........");
				System.out.println(t); 
			}
			
			
			StringBuilder text2= new StringBuilder("JAVA is Simple");
			System.out.println( text2.toString());
			System.out.println(".........");
			StringBuilder reverseStr = text2.reverse();
			System.out.println(  reverseStr.toString());
			System.out.println(".........");
			String len=("JAVAisSimple");
			System.out.println(len.length());
		}
			

	}
