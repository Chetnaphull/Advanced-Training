package test;
import org.junit.Test;
import ShoppingCart.test.test.Shopping;
public class Shopping {
	

	@SpringBootTest
	class SpringbootThymeleafWebAppApplicationTests {

		@Test
		void contextLoads() {
		}

	}

}
