package repo;


	import java.util.List;
	import controller.Product;
	import entity.Prod;

	import net.springboot.entity.Product;

	@Repository
	public interface ProductR extends JpaRepository<Prod, Long>{
		List<Prodt> findByName(String name);
	}
