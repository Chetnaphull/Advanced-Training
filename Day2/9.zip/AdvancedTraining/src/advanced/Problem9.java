package advanced;
public class Problem9 {

		static void frequency(int a[], int low, int high, int b [])
		{
			if (a[low] == a[high]) {
				
				b[a[low]] += high - low + 1;
			}
			else {
			
				int mid = (low + high) / 2;
				frequency(a, low, mid, b);
				frequency(a, mid + 1, high, b);
			}
		}
		static void freq(int x[], int y)
		{
	
			int[] c = new int[x[y - 1] + 1];

			frequency(x, 0, y - 1, c);
	
			for (int i = 0; i <= x[y - 1]; i++)
				if (c[i] != 0)
					System.out.println(i + " occurs " + c[i] + " times");
		}
		public static void main(String[] args)
		{
			int x[] = { 2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9 };
			int y = x.length;

			freq(x, y);
		}
	}


