package advanced;

import java.util.Scanner;

public class Problem10 {

	public static boolean isswap(String one,String two,String three )
	{
		if(one.length()==0 && two.length()==0 && three.length()==0)
		{
			return true;
		}
		if(three.length()==0)
		{
			return false;
		}
		if (one.length() != 0 && three.charAt(0) == one.charAt(0))
		{
            return isswap(one.substring(1), two, three.substring(1));
        }
        if (two.length() != 0 && three.charAt(0) == two.charAt(0))
        {
            return isswap(one, two.substring(1), three.substring(1));
        }
 
        return false;
    }
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter 1st String: ");
		String one=scan.nextLine();
		System.out.println("Enter 2nd String: ");
		String two=scan.nextLine();
		System.out.println("Enter 3rd String: ");
		String three=scan.nextLine();
		
		if(isswap(one, two, three))
		{
			System.out.println("It's an interleaving");
		}
		else
		{
			System.out.println("It's not an interleaving");
		}
	}


}

