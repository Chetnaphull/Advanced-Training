package advanced;
import java.util.*;
public class Problem12 {
	
	public static void repeating(int arr[], int num)
	   {
	         boolean a[] = new boolean[num];
	         Arrays.fill(a, false);
	         for (int i = 0; i < num; i++) 
	         {
	            if (a[i] == true)
	             continue;
	            
	            int count = 1;
	            
	            for (int j = i + 1; j < num; j++) 
	            {
	                if (arr[i] == arr[j]) {
	                   a[j] = true;
	                   count++;
	                }
	            }
	            if(count!=1)   
	               System.out.println("First Repeated Element is: "+arr[i]);
	            
	   }
	   
	  }

	   public static void main(String []args)
	   {
	      int arr[] = new int[]{1, 2, 3, 10, 4,2, 5, 7, 8};
	      int num = arr.length;
	      repeating(arr, num);
	   }
	}