package advanced;
import java.util.*;
public class Problem17 {

	static boolean Brackets(String b)
	{

		Deque<Character> stack
			= new ArrayDeque<Character>();

		for (int i = 0; i < b.length(); i++)
		{
			char a = b.charAt(i);

			if (a == '{' || a == '[' || a == '(')
			{
				
				stack.push(a);
				continue;
			}

			if (stack.isEmpty())
				return false;
			
			char check;
			switch (a) {
			case '}':
				check = stack.pop();
				if (check == '[' || check == '(')
					return false;
				break;

			case ']':
				check = stack.pop();
				if (check == '(' || check == '{')
					return false;
				break;

			case ')':
				check = stack.pop();
				if (check == '{' || check == '[')
					return false;
				break;
			}
		}

		return (stack.isEmpty());
	}

	
	public static void main(String[] args)
	{
		String b = "( �(�, �)�, �[�, �]�, �{�, �}�)";

		if (Brackets(b))
			System.out.println("It's Balanced. ");
		else
			System.out.println("It's Not Balanced. ");
	}
}
