package advanced;
import java.util.Scanner;
import java.util.Vector;

public class Problem11 {
	static int change[] = {1,2,5,10,20,50,100,500,2000};
    static int n = change.length;
  
    static void findMin(int v)
    {
   	        Vector<Integer> j = new Vector<>();
  
       	        for (int i = n - 1; i >= 0; i--)
        {
           
            while (v >= change[i]) 
            {
                v -= change[i];
                j.add(change[i]);
            }
        }		  
        
        for (int i = 0; i < j.size(); i++)
        {
            System.out.print(" " + j.elementAt(i));
        }
        System.out.println("\n The minimum number of coins is "+j.size());
    }	  
   
    @SuppressWarnings("resource")
	public static void main(String[] args) 
    {
    	 Scanner scanner=new Scanner(System.in);
    	   System.out.print("Enter the Rupees:");
    	   int n=scanner.nextInt();
            	   
        System.out.print(" The minimum changes of coin is"+ ": ");
        findMin(n);
    }
}

