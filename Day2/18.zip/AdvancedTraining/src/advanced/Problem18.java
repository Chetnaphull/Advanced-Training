package advanced;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Problem18 {
	public static String Fraction(int a, int b) {
		if (a == 0)
			return "0";
		if (b == 0)
			return "";

		StringBuilder result = new StringBuilder();
		if ((a < 0) ^ (b < 0))
			result.append("-");

		a = Math.abs(a);
		b = Math.abs(b);

		long qu = a / b;
		long rem = a % b * 10;

		result.append(String.valueOf(qu));
		if (rem == 0)
			return result.toString();

		result.append(".");
		Map<Long, Integer> m = new HashMap<>();
		while (rem != 0) {

			if (m.containsKey(rem)) {

				int index = m.get(rem);
				String part1 = result.substring(0, index);
				String part2 = "(" + result.substring(index, result.length()) + ")";
				return part1 + part2;
			}

			m.put(rem, result.length());
			qu = rem / b;
			result.append(String.valueOf(qu));
			rem = (rem % b) * 10;
		}
		return result.toString();
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		System.out.println("Enter the numerator: ");
		Scanner input = new Scanner(System.in);
		int a = input.nextInt();

		System.out.println("Enter the Denominator: ");
		Scanner input1= new Scanner(System.in);
		int b = input1.nextInt();

		String resString = Fraction(a, b);

		System.out.println(resString);

	}
}