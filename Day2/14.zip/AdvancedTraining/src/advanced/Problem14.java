package advanced;

import java.util.Arrays;

public class Problem14 {
	 public static void main(String[] args){
	      int[] a = new int[] {10,5,15};
	      int[] b = new int[] {20,3,2};
	      System.out.println("a[]="+Arrays.toString(a));
	      System.out.println("b[]="+Arrays.toString(b));
	      int unsorted1 = a.length;
	      int unsorted2  = b.length;
	      int [] sorted = new int[unsorted1 + unsorted2];
	      int i=0, j=0, k=0;
	      while (i < a.length) {
	        sorted[k] = a[i];
	         i++;
	         k++;
	      }
	      while (j < b.length) {
	         sorted[k] = b[j];
	         j++;
	         k++;
	      }
	      Arrays.sort(sorted);
	      System.out.println("Merge list is: "+Arrays.toString(sorted));
	   }
	}