package advanced;

public class Problem16 {
	public static int ClimbingStairs(int[] step) {
        if (step.length == 0) {
            return 0;
        }

        if (step.length == 1) {
            return step[0];
        }

        int number = step[0];
        int next = Math.min(step[1], step[0] + step[1]);
        for (int i = 2; i < step.length; i++) {
            int current = step[i] + Math.min(number, next);
            number = next;
            next = current;
        }

        return Math.min(next, number);
    }

    public static void main(String[] args) {
        int min = Problem16.ClimbingStairs(new int[] {3});
        System.out.println(min+" ways to climb to the top.");
    }
}

