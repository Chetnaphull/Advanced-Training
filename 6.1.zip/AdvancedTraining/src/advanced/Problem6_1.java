package advanced;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Problem6_1 {
@SuppressWarnings({ "unused", "resource" })
public static void main(String[] args) {
		
		ArrayList<String> x1=new ArrayList<String>();
		 int arr;
		 Scanner input= new Scanner(System.in);
		 System.out.println("Enter the total number of students:");
		 arr=input.nextInt();
		 System.out.println("Enter the student names:");
		for(int i=0;i<arr;i++)
		{
			x1.add(input.next());
		}
		System.out.println("student list:");
		for(String x:x1)
		{
				System.out.println("Enter the name to be searched:");
			    String str=input.next(); 
			    int position=Collections.binarySearch(x1,str);
				System.out.println("posistion is:"+position);
				
				}
		 }

	

}

